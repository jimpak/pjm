package org.pjm.todolistapp

data class DayJob(
    var title: String,
    var content: String
)
