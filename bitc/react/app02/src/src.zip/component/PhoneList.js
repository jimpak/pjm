import { Component } from 'react';

class PhoneList extends Component {
    render() {
        return <div>PhoneList</div>;
    }
}

export default PhoneList;
