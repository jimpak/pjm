package grade;

public interface GradeEvaluation {
	public String getGrade(int point);
}
